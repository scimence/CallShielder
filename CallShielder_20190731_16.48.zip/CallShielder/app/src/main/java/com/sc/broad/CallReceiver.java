
package com.sc.broad;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;

import com.sc.call.CallProcess;


/* AndroidManifest.xml添加配置

<uses-permission android:name="android.permission.READ_PHONE_STATE" />
<uses-permission android:name="android.permission.CALL_PHONE" />
<uses-permission android:name="android.permission.PROCESS_OUTGOING_CALLS" />
    
 <!-- 静态广播注册，接收来电、去电广播 -->
 <receiver android:name="com.sc.broad.CallReceiver" >
	 <intent-filter>
		 <action android:name="android.intent.action.PHONE_STATE" />
		 <action android:name="android.intent.action.NEW_OUTGOING_CALL" />
	 </intent-filter>
 </receiver>
 */

/** 来电、去电广播监听 */
public class CallReceiver extends BroadcastReceiver
{
	private Context context;
	
	@Override
	public void onReceive(Context context, Intent intent)
	{
		this.context = context;
		String action = intent.getAction();
		// Toast.makeText(context, "action" + action, Toast.LENGTH_SHORT).show();
		
		if (action.equals("android.intent.action.NEW_OUTGOING_CALL"))
		{	// 接收到去电广播，执行去电处理逻辑
			
//			IntentFilter intentFilter = new IntentFilter(Intent.ACTION_NEW_OUTGOING_CALL);
//			context.registerReceiver(this, intentFilter);
//			String phoneNumber = getResultData();
			String phoneNumber = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER);
			phoneNumber = phoneNumber.replace("-", "").replace(" ", "");		// 剔除号码中的分隔符
			
			CallProcess.OutCall(context, phoneNumber);			// 去电处理逻辑
		}
		else if (action.equals("android.intent.action.PHONE_STATE"))
		{	// 接收到来电广播，执行来电监听处理逻辑
			TelephonyManager tm = (TelephonyManager) context.getSystemService(Service.TELEPHONY_SERVICE);
			tm.listen(listener, PhoneStateListener.LISTEN_CALL_STATE);
		}
	}
	
	private PhoneStateListener listener = new PhoneStateListener()
	{
		@Override
		public void onCallStateChanged(int state, String phoneNumber)
		{
			super.onCallStateChanged(state, phoneNumber);
			
			phoneNumber = phoneNumber.replace("-", "").replace(" ", "");		// 剔除号码中的分隔符
			switch (state)
			{
				case TelephonyManager.CALL_STATE_IDLE:
					CallProcess.HungUp(context, phoneNumber);	// 空闲/挂断处理逻辑
					break;
				
				case TelephonyManager.CALL_STATE_OFFHOOK:
					CallProcess.OffHook(context, phoneNumber);	// 接听处理逻辑
					break;
				
				case TelephonyManager.CALL_STATE_RINGING:		// 来电处理逻辑
					CallProcess.Ringing(context, phoneNumber);
					break;
			}
		}
	};
}
