
package sci.callshielder;

import sci.tool.ActivityComponent;
import android.os.Bundle;
import android.widget.Toast;


public class ShieldActivity extends ActivityComponent
{
	@Override
	public void Init(Bundle savedInstanceState)
	{
		this.setContentView("shield_layout");	// 设置Activity页面布局
		
		// this.setOptionMenu("shield_option"); // 设置Option菜单
		this.AddOptionMenu("拦截设置");
		this.AddOptionMenu("不拦截");
		this.AddOptionMenu("菜单项3(子菜单1;子菜单2;子菜单3(子菜单3-1;子菜单3-2(3-2-1;3-2-2;3-2-3)))");
		
		this.AddContextMenu(Button("btnKeepSet"), "Context菜单1");
		this.AddContextMenu(Button("btnKeepSet"), "Context菜单2(2-1;2-2)");
		
		this.setContextMenu_Res(Button("btnClearRecord"), "shield_option");
	}
	
	@Override
	public void Click(String viewId)
	{
		Toast.makeText(this, viewId, Toast.LENGTH_SHORT).show();
		
		if (viewId.equals("btnShieldSet"))
		{
//			this.setPopuptMenu_Res(Button("btnKeepSet"), "shield_option");
			this.AddPopupMenu(Button("btnKeepSet"), new String[]{"弹出菜单项1(子菜单项1;子菜单项2(子菜单3;子菜单4);子菜单项3)","弹出菜单项2","弹出菜单项3"});
		}
		else if (viewId.equals("btnKeepSet"))
		{	
			
		}
		else if (viewId.equals("btnClearRecord"))
		{	
			
		}
		
	}
	
	// public boolean onOptionsItemSelected(MenuItem item)
	// {
	// switch (item.getItemId()) {
	//
	// }
	// return super.onOptionsItemSelected(item);
	// }
	
}
