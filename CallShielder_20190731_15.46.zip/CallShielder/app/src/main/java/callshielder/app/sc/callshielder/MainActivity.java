package callshielder.app.sc.callshielder;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;

import sc.google.admob.AdmobSdk;

public class MainActivity extends AppCompatActivity
{
    //    private AdView mAdView;

//    InterstitialAd ad;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
////        setContentView(R.layout.activity_main);
//
//
////        String APPLICATION_ID = getMetaData(this, "com.google.android.gms.ads.APPLICATION_ID");
////        MobileAds.initialize(this, APPLICATION_ID);
//        //        MobileAds.initialize(this, "ca-app-pub-3940256099942544~3347511713");
//
//        // 布局配置载入 横幅广告
//        //        mAdView = findViewById(R.id.adView);
//        //        AdRequest adRequest = new AdRequest.Builder().build();
//        //        mAdView.loadAd(adRequest);
//
//        // AdmobSdk初始化
//        AdmobSdk.Init(this, "");
//
//        // 展示横幅广告
//        LinearLayout liner1 = (LinearLayout) this.findViewById(R.id.Liner1);
//        AdmobSdk.ShowAdView(this, "", liner1);
//
//        // 展示插屏广告
//        AdmobSdk.ShowInterstitialAd(this, "");
    }

    public void click(View view)
    {
//        AdmobSdk.Show(ad);
    }
}
