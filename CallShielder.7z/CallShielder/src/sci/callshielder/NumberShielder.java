
package sci.callshielder;

import java.util.List;

import android.content.Context;

import com.sc.call.CallProcess;
import com.sc.tool.Preference;
import com.sc.tool.TelephonyTool;


/** 根据设置信息，对来电屏蔽处理逻辑 */
public class NumberShielder
{
	public static Preference mContact = null;	// 联系人信息
	

	// 获取联系人信息
	public static List<String> ContactList(Context context)
	{
		if (mContact == null) mContact = new Preference(context, MainActivity.ContactSet);
		return mContact.Keys();
	}
	
	/** 获取手机号对应的联系人名称 */
	public static String getName(Context context, String number)
	{
		if (mContact == null) mContact = new Preference(context, MainActivity.ContactSet);
		String name = mContact.get(number);
		return name;
	}
	
	public static Preference mShield = null;	// 屏蔽号码、规则
	
	// 获取屏蔽规则配置信息
	public static List<String> ShieldList(Context context)
	{
		if (mShield == null) mShield = new Preference(context, ShieldActivity.SetName);
		return mShield.Values();
	}
	
	public static Preference mUnShield = null;	// 不屏蔽的号码、规则
	
	// 获取不屏蔽（白名单）规则配置信息
	public static List<String> UnShieldList(Context context)
	{
		if (mUnShield == null) mUnShield = new Preference(context, UnshieldActivity.SetName);
		return mUnShield.Values();
	}
	
	// ------------------
	
	/** 检查来电号码，根据设置对来电进行屏蔽 */
	public static void CheckShield(Context context, String phoneNumber)
	{
		List<String> unShieldList = UnShieldList(context);
		for (String unshield : unShieldList)
		{
			if (EqualInRule(unshield, phoneNumber)) 		// 若号码符合不屏蔽逻辑配置，则不执行处理
			{
				CallProcess.WriteLog("白名单("+ unshield+")，不屏蔽:", context, phoneNumber);
				return;	
			}
		}
		
		List<String> shieldList = ShieldList(context);
		if (shieldList.contains("屏蔽非联系人"))
		{	
			List<String> contactList = ContactList(context);// 获取手机联系人信息
			if(!contactList.contains(phoneNumber))			// 不含有该号码，则屏蔽
			{
				CallProcess.WriteLog("屏蔽规则("+ "屏蔽非联系人"+"):", context, phoneNumber);
				DoShield(context);
				return;
			}
		}
		
		for (String shield : shieldList)
		{
			if (EqualInRule(shield, phoneNumber))			// 若号码符合不屏蔽逻辑配置，则不执行处理
			{
				CallProcess.WriteLog("屏蔽规则("+ shield +")，屏蔽:", context, phoneNumber);
				DoShield(context);
				return;
			}
		}
	}
	
	// 执行屏蔽操作
	private static void DoShield(Context context)
	{
		TelephonyTool.answerRingingCall(context);	// 接听
		Sleep(3100);								// 延时3.1秒
		TelephonyTool.endCall(context);				// 自动挂断
		return;
	}
	
	private static void Sleep(long time)
	{
		try
		{
			Thread.sleep(time);
		}
		catch (Exception ex)
		{	
			
		}
	}
	
	/** 判定phoneNumber是否匹配规则rule（*匹配所有字符串值） */
	public static boolean EqualInRule(String rule, String phoneNumber)
	{
		if(rule.trim().equals("")) return false;	// 屏蔽规则为空串，为错误数据不处理
		
		char[] phoneA = phoneNumber.toCharArray();
		char[] ruleA = rule.toCharArray();
		int minLen = ruleA.length < phoneA.length ? ruleA.length : phoneA.length;
		for (int i = 0; i < minLen; i++)
		{
			if (ruleA[i] != '*' && ruleA[i] != '#' && phoneA[i] != ruleA[i]) return false;
		}
		
		return true;
	}
}
