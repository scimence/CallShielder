
package sci.callshielder;

import java.util.ArrayList;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.sc.tool.ActivityComponent;
import com.sc.tool.Preference;


public class ShieldActivity extends ActivityComponent
{
	public static String SetName = "shield_data";
	Preference Set = new Preference(this, SetName);
	
	LinearLayout linerSetting = null;
	ArrayList<TextView> MsgList = new ArrayList<TextView>();	// 信息
	
	CheckBox checkAll = null;
	
	@Override
	public void Init(Bundle savedInstanceState)
	{
		this.setContentView("shield_layout");
		this.setTitle("拦截设置");
		
		linerSetting = this.LinearLayout("linearSettings");
		checkAll = CheckBox("checkAll");
		
		loadAllSet();
	}
	
	@Override
	public void Click(String viewId)
	{
		if (viewId.equals("btnAdd"))
		{
			creatNewLine(linerSetting, "");
		}
		else if (viewId.equals("btnSave"))
		{
			SaveSetting();
		}
		else if (viewId.equals("btnClear"))
		{
			ClearSet();
		}
		else if (viewId.equals("checkAll"))
		{
			SaveCheckAll();
		}
	}
	
	// Toast显示消息
	public void ShowToast(String msg)
	{
		Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
	}
	
	private int I = 0;
	
	// 添加新的配置信息行
	public void creatNewLine(LinearLayout root, String msg)
	{
		Context context = root.getContext();
		I++;
		
		LinearLayout.LayoutParams lineParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		
		LinearLayout line1 = new LinearLayout(context);
		line1.setOrientation(LinearLayout.HORIZONTAL);
		
		root.addView(line1, lineParams);	// 添加line1控件
		{
			TextView label = new TextView(context);
			
			label.setText(" " + I + "：");
			line1.addView(label);
			
			EditText text = new EditText(context);
			text.setHint("请输入拦截号码 或 规则通配符号*");
			if (msg != null && !msg.equals("")) text.setText(msg);
			line1.addView(text, textParams);
			
			MsgList.add(text);
		}
	}
	
	// 保存失败的数据信息
	private void SaveSetting()
	{
		Set.clear();
		
		if (checkAll.isChecked())
		{
			Set.put("checkAll", "屏蔽非联系人");
		}
		
		ArrayList<String> tmp = new ArrayList<String>();
		
		for (int i = 0; i < MsgList.size(); i++)
		{
			TextView view = MsgList.get(i);
			String msg = view.getText().toString().trim();
			if(msg.equals("")) continue;
			
			if (!tmp.contains(msg))	// 缓存去重
			{
				Set.put("msg" + (i + 1), msg);
				tmp.add(msg);
			}
		}
		
		ShowToast("配置信息已保存");
		
		NumberShielder.mShield = null;	// 设为空,刷新配置
	}
	
	// 清空配置
	private void ClearSet()
	{
		new AlertDialog.Builder(this).setTitle("确定清空所有配置信息？").setPositiveButton("确定", new DialogInterface.OnClickListener()
		{
			@Override
			public void onClick(DialogInterface dialog, int which)
			{
				Set.clear();
				linerSetting.removeAllViews();
				
				ShowToast("配置信息已清空");
				NumberShielder.mShield = null;	// 设为空,刷新配置
			}
		}).setNegativeButton("取消", null).show();
	}
	
	// 载入所有已保存的配置信息
	private void loadAllSet()
	{
		boolean cintainsCheckAll = false;
		for (String key : Set.Keys())
		{
			if (key.equals("checkAll"))
				cintainsCheckAll = true;
			else
			{
				String value = Set.get(key);
				creatNewLine(linerSetting, value);
			}
		}
		checkAll.setChecked(cintainsCheckAll);
	}
	
	// 保存 checkAll配置
	private void SaveCheckAll()
	{
		if (checkAll.isChecked())
		{
			if (!Set.Keys().contains("checkAll")) Set.put("checkAll", "屏蔽非联系人");
		}
		else 
		{
			if (Set.Keys().contains("checkAll")) Set.remove("checkAll");
		}
	}
}
