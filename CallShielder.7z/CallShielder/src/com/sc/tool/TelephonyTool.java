
package com.sc.tool;

import java.lang.reflect.Method;

import android.content.Context;
import android.telephony.TelephonyManager;

import com.android.internal.telephony.ITelephony;

/** 电话操作接口，
 * 接听：answerRingingCall、
 * 挂断：endCall、
 * 静音：silenceRinger 
 * */
public class TelephonyTool
{
	// https://github.com/alitamoor65/CallBlocker
	
	/** 获取ITelephony实例对象 */
	public static ITelephony getITelephony(Context context)
	{
		ITelephony itelephony = null;
		
		try
		{
			TelephonyManager telephony = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
			
			// 调用TelephonyManager.getITelephony()获取ITelephony实例对象
			// Class c = Class.forName(telephony.getClass().getName());
			Method m = telephony.getClass().getDeclaredMethod("getITelephony");	
			m.setAccessible(true);
			itelephony = (ITelephony) m.invoke(telephony);
		}
		catch (Exception ex)
		{	
			
		}
		
		return itelephony;
	}
	
	/** 挂断 */
	public static boolean endCall(Context context)
	{
		ITelephony I = getITelephony(context);
		try
		{
			return I.endCall();
		}
		catch (Exception ex)
		{
			return false;
		}
	}
	
	/** 接听 */
	public static void answerRingingCall(Context context)
	{
		ITelephony I = getITelephony(context);
		try
		{
			I.answerRingingCall();
		}
		catch (Exception ex)
		{}
	}
	
	/** 静音 */
	public static void silenceRinger(Context context)
	{
		ITelephony I = getITelephony(context);
		try
		{
			I.silenceRinger();
		}
		catch (Exception ex)
		{}
	}
	
}
