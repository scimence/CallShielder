
package com.sc.tool;

import java.util.HashMap;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;

/** 获取联系人信息。
 * 1、获取所有联系人信息：ContactTool.GetAll(this);
 * 2、选取联系人信息：ContactTool.SelectContact(this); 
 **/
public class ContactTool extends Activity
{
	/** 获取所有联系人信息，需要添加权限: uses-permission android:name="android.permission.READ_CONTACTS" */
	public static HashMap<String, String> GetAll(Context context)
	{
		HashMap<String, String> map = new HashMap<String, String>();		// 记录联系人信息
		
		ContentResolver resolver = context.getContentResolver();
		Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;			// 获取所有电话信息
		String[] projection = { ContactsContract.CommonDataKinds.Phone.NUMBER,	// 电话号码
				ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME				// 姓名
		};
		
		Cursor cursor = resolver.query(uri, projection, null, null, null);	// 获取联系人信息
		if (cursor != null)
		{
			while (cursor.moveToNext())
			{
				String number = cursor.getString(0);
				String name = cursor.getString(1);
				
				if (number.trim().equals("")) continue;
				number = number.replace("-", "").replace(" ", "");		// 剔除号码中的分隔符
				if (!map.containsKey(number)) map.put(number, name);
			}
			cursor.close();
		}
		return map;
	}
	
	//------------------------------
	// AndroidManifest.xml中添加：
	// <uses-permission android:name="android.permission.READ_CONTACTS"/>
	// <activity android:name="com.sc.tool.ContactTool"></activity>
	
	// 选取联系人，示例： 
	// 1、调用 ContactTool.SelectContact(this); 
	
	// 2、在Activity的 onActivityResult中解析选取到的联系人信息
	//	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	//	{
	//		super.onActivityResult(requestCode, resultCode, data);
	//		if (requestCode == ContactTool.Pick_Contact)
	//		{
	//			if (resultCode == Activity.RESULT_OK)
	//			{
	//				String name = data.getExtras().getString("name");
	//				String number = data.getExtras().getString("number");
	//				
	//				Toast.makeText(this, name + " -> " + number, Toast.LENGTH_SHORT).show();
	//			}
	//		}
	//	}
	
	/** 选取联系人信息 */
	public static void SelectContact(Activity context)
	{
		context.startActivityForResult(new Intent(context, ContactTool.class), Pick_Contact);
	}
	
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		this.startActivityForResult(new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI), Pick_Contact);
	}
	
	public static final int Pick_Contact = 40003;
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);
		
		if (requestCode == Pick_Contact)
		{
			String name = "";
			String number = "";
			
			// 获取联系人选取结果
			if (resultCode == Activity.RESULT_OK)
			{
				Uri uri = data.getData();
				Cursor cursor = managedQuery(uri, null, null, null, null);
				if (cursor != null)
				{
					cursor.moveToFirst();
					name = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));			// 联系人名称
					String contactId = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));		// 联系人ID
					
					ContentResolver resolver = getContentResolver();
					Cursor phoneCursor = resolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,
							ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = " + contactId, null, null);		// 查询联系人id对应的信息
					if (phoneCursor.moveToNext())
					{
						number = phoneCursor.getString(phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
						number = number.replace("-", "").replace(" ", "");		// 剔除号码中的分隔符
					}
				}
			}
			
			// 返回联系人信息
			Intent dataR = new Intent();
			dataR.putExtra("name", name);
			dataR.putExtra("number", number);
			this.setResult(Activity.RESULT_OK, dataR);
			
			this.finish();
		}
	}
}
