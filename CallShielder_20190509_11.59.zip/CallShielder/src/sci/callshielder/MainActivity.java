
package sci.callshielder;

import java.io.File;
import java.util.HashMap;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import com.sc.service.CallService;
import com.sc.tool.ActivityComponent;
import com.sc.tool.ContactTool;
import com.sc.tool.FileTool;
import com.sc.tool.Preference;
import com.sc.update.AppUpdate;


public class MainActivity extends ActivityComponent
{
	@Override
	public void Init(Bundle savedInstanceState)
	{
		this.setContentView("main_layout"); // 设置Activity页面布局
		
		String logFile = FileTool.getLastFile(FileTool.LogPath);	// 获取目录下的文件
		FileTool.showFileData(this.TextView("textMSG"), logFile);	// 显示文件内容
		
		LoadContactInfo();	// 载入联系人信息
		CallService.GetInstance().start(this, CallService.class, 500);	// 启动来电屏蔽服务
		
		// this.setOptionMenu("shield_option"); // 设置Option菜单
		// this.AddOptionMenu("拦截设置");
		// this.AddOptionMenu("不拦截");
		// this.AddOptionMenu("菜单项3(子菜单1;子菜单2;子菜单3(子菜单3-1;子菜单3-2(3-2-1;3-2-2;3-2-3)))");
		//
		// this.AddContextMenu(Button("btnKeepSet"), "Context菜单1");
		// this.AddContextMenu(Button("btnKeepSet"), "Context菜单2(2-1;2-2)");
		//
		// this.setContextMenu_Res(Button("btnClearRecord"), "shield_option");

		String ConfigUrl = "https://scimence.gitee.io/CallShielder/update.txt";	// 服务端最新版本配置信息
		String curVersion = "20190401";											// 当前版本信息
		AppUpdate.CheckUpdate(this, ConfigUrl, curVersion);						// 检测版本自动更新
	}
	
	@Override
	public void Click(String viewId)
	{
		// Toast.makeText(this, viewId, Toast.LENGTH_SHORT).show();
		
		if (viewId.equals("btnShieldSet"))
		{
			// this.setPopuptMenu_Res(Button("btnKeepSet"), "shield_option");
			// this.AddPopupMenu(Button("btnKeepSet"), new String[] { "弹出菜单项1(子菜单项1;子菜单项2(子菜单3;子菜单4);子菜单项3)", "弹出菜单项2", "弹出菜单项3" });
			
			ActivityComponent.Show(this, ShieldActivity.class);
		}
		else if (viewId.equals("btnKeepSet"))
		{
			// HashMap<String, String> map = ContactTool.GetAll(this);
			ActivityComponent.Show(this, UnshieldActivity.class);
		}
		else if (viewId.equals("btnClearRecord"))
		{
//			ContactTool.SelectContact(this);
			 Clear();
		}
	}
	
	public static String ContactSet = "contact_data";
	Preference Contact = new Preference(this, MainActivity.ContactSet);	// (number,name)
	
	// 载入联系人信息
	private void LoadContactInfo()
	{
		HashMap<String, String> contacts = ContactTool.GetAll(this);
		for (String key : contacts.keySet())
		{
			String value = contacts.get(key);
			Contact.put(key, value);
		}
		
		NumberShielder.mContact = null;	// 设为空,刷新配置
	}
	
	private void Clear()
	{
		new AlertDialog.Builder(this).setTitle("确定清空所有log记录？").setPositiveButton("确定", new DialogInterface.OnClickListener()
		{
			@Override
			public void onClick(DialogInterface dialog, int which)
			{
				FileTool.ClearDir(new File(FileTool.LogPath));
				MainActivity.this.TextView("textMSG").setText("已清空！");
			}
		}).setNegativeButton("取消", null).show();
	}
	
//	protected void onActivityResult(int requestCode, int resultCode, Intent data)
//	{
//		super.onActivityResult(requestCode, resultCode, data);
//		if (requestCode == ContactTool.Pick_Contact)
//		{
//			if (resultCode == Activity.RESULT_OK)
//			{
//				String name = data.getExtras().getString("name");
//				String number = data.getExtras().getString("number");
//				
//				Toast.makeText(this, name + " -> " + number, Toast.LENGTH_SHORT).show();
//			}
//		}
//	}
	
	// public boolean onOptionsItemSelected(MenuItem item)
	// {
	// switch (item.getItemId()) {
	//
	// }
	// return super.onOptionsItemSelected(item);
	// }
	
}
