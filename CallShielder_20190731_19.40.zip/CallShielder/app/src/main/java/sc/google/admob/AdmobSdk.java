package sc.google.admob;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.util.Log;
import android.widget.LinearLayout;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.sc.tool.ThreadTool;

public class AdmobSdk
{
    //    public static String APPLICATION_ID = "";

    /** 获取MainFest中MetaData对应的key节点数据 */
    public static String getMetaData(Activity activity1, String key)
    {
        ApplicationInfo appInfo;
        try
        {
            appInfo = activity1.getPackageManager().getApplicationInfo(activity1.getPackageName(), PackageManager.GET_META_DATA);
            String value = appInfo.metaData.get(key).toString();
            Log.d("getMetaData", key + " == " + value);
            return value;
        }
        catch (PackageManager.NameNotFoundException e)
        {
            e.printStackTrace();
            return null;
        }
    }
    /**
     * 初始化
     */
    public static void Init(Activity context, String APPLICATION_ID)
    {
        if (APPLICATION_ID == null || APPLICATION_ID.equals(""))
            APPLICATION_ID = getMetaData(context, "com.google.android.gms.ads.APPLICATION_ID");

        MobileAds.initialize(context, APPLICATION_ID);
    }

    /**
     * 显示横幅广告
     */
    public static AdView ShowAdView(Activity context, String bannerAdId, LinearLayout liner1)
    {
        if (bannerAdId == null || bannerAdId.equals(""))
            bannerAdId = "ca-app-pub-3940256099942544/6300978111";

        // 代码配置载入 横幅广告
        final AdView adView = new AdView(context);
        adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId(bannerAdId);
        // TODO: Add adView to your view hierarchy.

        adView.loadAd( new AdRequest.Builder().build());

        liner1.addView(adView);
        return adView;
    }

    /**
     * 显示插屏广告
     */
    public static InterstitialAd ShowInterstitialAd(Activity context, String AdId)
    {
        if (AdId == null || AdId.equals("")) AdId = "ca-app-pub-3940256099942544/1033173712";

        // 代码配置载入 横幅广告
        final InterstitialAd mInterstitialAd = new InterstitialAd(context);
        mInterstitialAd.setAdUnitId(AdId);
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        // TODO: Add adView to your view hierarchy.

        mInterstitialAd.setAdListener(new AdListener()
        {
            @Override
            public void onAdLoaded()    // 插屏广告载入完成后自动展示
            {
                // Code to be executed when an ad finishes loading.
                if (mInterstitialAd.isLoaded()) mInterstitialAd.show();
            }

            @Override
            public void onAdClosed()    // 关闭广告时，载入新的广告
            {
                //                mInterstitialAd.loadAd(new AdRequest.Builder().build());
            }
        });

        //        Show(mInterstitialAd);

        return mInterstitialAd;
    }

    //    public static void Show(InterstitialAd ad)
    //    {
    //        if (ad.isLoaded()) ad.show();
    //        else
    //        {
    //            Log.d("TAG", "The interstitial wasn't loaded yet.");
    //        }
    //    }

}
